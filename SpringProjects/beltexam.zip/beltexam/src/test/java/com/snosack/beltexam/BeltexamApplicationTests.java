package com.snosack.beltexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeltexamApplicationTests {

	@Test
	void contextLoads() {
	}

}
