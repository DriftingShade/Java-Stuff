package com.snosack.displaydate.model;

import java.util.Date;

public class DateTimeModel {
    private Date currentDate;
    private String currentTime;
}