package com.snosack.projectmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
